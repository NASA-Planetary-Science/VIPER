function chi_batch

Chi_Plots('1979_064_10_16_00_CHI_ARRAYS.txt',9,3,char('V_r (km/s)','V_{\phi} (km/s)','V_z (km/s)','T_i (eV)','n_{O^+} (cm^{-3})','n_{O^{++}} (cm^{-3})','n_{S^{+++}} (cm^{-3})','n_{S^+} (cm^{-3})','n_{SO_2^+} (cm^{-3})'))
%Chi_Plots('1979_064_00_28_47_CHI_ARRAYS.txt',3,3,char('V_{\phi} (km/s)','T_i (eV)','n_{O^+} (cm^{-3})'))
%Chi_Plots('1979_064_07_07_11_CHI_ARRAYS.txt',2,3,char('T_i (eV)','n_{O^+} (cm^{-3})'))
%Chi_Plots('1979_062_10_23_58_CHI_ARRAYS.txt',3,3,char('V_{\phi} (km/s)','T_i (eV)','n_{O^+} (cm^{-3})'))

end