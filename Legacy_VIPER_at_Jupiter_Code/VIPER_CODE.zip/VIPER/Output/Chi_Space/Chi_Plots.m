function [out1] = Chi_Plots(filename,npar,nsigma,axtitles)
% INPUTS
% filename - String filename of file that contains Chi-Space calculations
%            There will be similarly named files that contain the best
%            parameters and the 1-Sigma uncertainties in those parameters.
%            IDL automatically generates these text files when it generates
%            the filename file. If files are manually renamed then you must
%            adjust for that in this code.
% npar     - Number of parameters
% nsigma   - Number of sigma that were calculated (Usually 3)
% axtitles - String array of titles to use for titles on the axes. Give
%            parameters in the order they are in IDL code
%
%
%
%This function reads in data produce by the chi_square_arrays program in
%IDL. It then produces contour plots since the Matlab graphics processing
%is better than that of IDL.
%
%At this current time, one must be familiar with the output of the IDL
%function and how to read it back in into this Matlab code.

nnn = (npar*npar-npar)/2;

%Axes labels
%axtitles = char('V_r','V_{\phi}','V_z','T_i','n_{O^{++}}','n_{O^+}','n_{S^+}');
%axtitles = char('V_{\phi}','T_i','n_{O^+}'); %Hot Torus parameters

%Do arithmetic on string to get proper parameter and uncertainty files
filenamepar = strrep(filename, '_ARRAYS.txt','_Parameters_MATLAB.txt');
filenameunc = strrep(filename, '_ARRAYS.txt','_Uncertainties_MATLAB.txt');

x = load(filename);
sizex = size(x);
sizex = sizex(1);
npts = sqrt(sizex/nnn);

b1 = textread(filenamepar,'%f');
b2 = textread(filenameunc, '%f');

%Assign variables from text read in
sizeb1 = size(b1);
bn = sizeb1(1);
best_p = b1(1:bn);  %Best fit parameters are
uncert = b2(1:bn);  %1 sigma uncertainty in parameters

%Check that none of the uncertainties are zero. IDL code should handle that
for i = 1:npar
    if uncert(i) == 0;
        uncert(i) = 1;
    end
end

Z = zeros(npts,npts);  %Initialize array to be filled later
Chi_array_all = zeros(npts,npts,nnn);
Chi_array_all(:) = x;

%Calculate the values for the axes of the plots
uncertt = uncert*nsigma;
values = zeros(bn,npts);
StepSize = (npts-1)/2; %Stepsize between x and y values on plot
for i = 1:npts
    values(:,i) = best_p(:) - uncertt(:) + (i-1)*uncertt(:)/StepSize;
end

if filename == '1979_062_10_23_58_CHI_ARRAYS.txt';
    upper_cb_lim = 32;
    cb_tick = [0:5:30];
elseif filename == '1979_064_00_28_47_CHI_ARRAYS.txt';
    upper_cb_lim = 35;
    cb_tick = [0:4:32];
elseif filename == '1979_064_07_07_11_CHI_ARRAYS.txt';
    upper_cb_lim = 22;
    cb_tick = [0:3:21];
elseif filename == '1979_064_10_16_00_CHI_ARRAYS.txt';
    upper_cb_lim = 30;
    cb_tick = [0:4:28];
end

count = 0; %Initialize a count to fill the subplot number
for jj = 1:npar;     %Loop for where to put the plot
    for ii = 1:npar;
        if ii <= jj, continue, end 
        count = count+1;

        %jj and ii are the rows and columns respectively for the plots to
        %exist on
        subplotn = (jj-1)*npar + ii - jj; %Use correct subplot command


        
        Contourlev = [0:0.2:60]; %Set contour levels every 10 in reduced chi squared
        tick = [0:10:60]; %Set tick marks appropriately
        
        Chi_val = Chi_array_all(:,:,count); %Extract proper row of array
        Chi_val = Chi_val.'; %Transpose because IDL prints rows and then columns while Matlab reads columns then rows
        Chir    = Chi_val(:); %Calculate reduced chi squared

        Z0      = min(Chir);
        Z(:)    = Chir(:)-Z0; %Calculate reduced chi squared relative to minimum
        
        
        xran = values(ii,:); %Range of x and y values for plot axes
        yran = values(jj,:);

        Chilevels = 2*gammaincinv([0.682689492137086, 0.954499736103642, 0.997300203936740],npar/2); %Levels obtained from Rob
        
        %Produce contour plots in appropriate grid spacing
        subplot(npar-1,npar-1,subplotn);
        contour(xran,yran,Z,50,'Fill','on','LevelList',Contourlev);
        
        %Put axes labels on plots if they are at the top or the right
        %ax = axes;

        
        pos = get(gca,'Position');
        c = colorbar('Ticks',cb_tick);
        title(c,'\chi_R^2-\chi_{R_0}^2');
        if npar > 2;
            c.Visible = 'off';
            set(gca, 'Position', pos);
        elseif npar == 2;
            %c.Location = 'South';
            %c.Position = [c.Position(1),pos(2)-0.1,c.Position(3),c.Position(4)];
        end
        set(gca,'clim',[0,upper_cb_lim]);
        set(gca, 'FontSize', 16);
        set(c, 'FontSize', 16);
        
        axis square
        
        if jj == 1 
            % With the 9 parameters, this setting doesn't work too well
            if npar == 9;
                text(0.07*(max(xran)-min(xran))+min(xran),max(yran)+0.3*(max(yran)-min(yran)),axtitles(ii,:),'FontSize',16);
            elseif npar == 2;
                text(0.45*(max(xran)-min(xran))+min(xran),min(yran)-0.1*(max(yran)-min(yran)),axtitles(ii,:),'FontSize',16);
            else;
                text(0.42*(max(xran)-min(xran))+min(xran),max(yran)+0.14*(max(yran)-min(yran)),axtitles(ii,:),'FontSize',16);
            end
        end;
        if ii == npar
            if npar ~= 2;
                text(max(xran)+0.1*(max(xran)-min(xran)),(min(yran)+max(yran))/2,axtitles(jj,:),'FontSize',16);
            else
                text(min(xran)-0.2*(max(xran)-min(xran)),(min(yran)+max(yran))/2,axtitles(jj,:),'FontSize',16);
            end
        end;
        
        
        xbest = values(ii,(npts-1)/2+1);
        ybest = values(jj,(npts-1)/2+1);
        ax = gca;
        axisscale = 3.08;
        ax.XLim = [xbest-uncert(ii)*axisscale, xbest+uncert(ii)*axisscale];
        ax.YLim = [ybest-uncert(jj)*axisscale, ybest+uncert(jj)*axisscale];
        % Make the right number of digits appear
        xvals = [xbest-uncert(ii)*3,xbest,xbest+uncert(ii)*3];
        yvals = [ybest-uncert(jj)*3,ybest,ybest+uncert(jj)*3];
        xsigf = [4,4,4];
        ysigf = [4,4,4];
        for dumvar = 1:3;
            if xvals(dumvar) < 1;
                xsigf(dumvar) = 3;
            end
            if yvals(dumvar) < 1;
                ysigf(dumvar) = 3;
            end
        end
        
        
        xTickarr = [round(xvals(1),xsigf(1),'significant'),round(xvals(2),xsigf(2),'significant'),round(xvals(3),xsigf(3),'significant')];
        yTickarr = [round(yvals(1),ysigf(1),'significant'),round(yvals(2),ysigf(2),'significant'),round(yvals(3),ysigf(3),'significant')];

        
        ax.XTick = xTickarr;
        ax.YTick = yTickarr;
        set(ax,'FontSize',14);
        %Overplot Commands
        hold on
        %Plot Contours of the correct levels from Rob's table for 1, 2, and
        %3 sigma levels
        contour(xran,yran,Z,3,'LevelList',Chilevels,'LineColor','red','LineStyle','- -');
        
        %Calculate values to plot the one sigma lines from uncertainties of
        %parameters
        %xbest = values(ii,(npts-1)/2+1);
        %ybest = values(jj,(npts-1)/2+1);
        %Go one sigma to the left and right of the best fit 
        xarr_1 = [xbest-uncert(ii),xbest,xbest+uncert(ii)]; 
        yarr_1 = [ybest,ybest,ybest];
        xarr_2 = [xbest,xbest,xbest];
        yarr_2 = [ybest-uncert(jj),ybest,ybest+uncert(jj)];
        plot(xarr_1,yarr_1,'white',xarr_2,yarr_2,'white');
        
        hold off
    end
end


%Position the colorbar in the right location
if filename == '1979_062_10_23_58_CHI_ARRAYS.txt'; %GOOD
    posc = [0.12,0.25,0.37,0.05];
elseif filename == '1979_064_00_28_47_CHI_ARRAYS.txt'; %GOOD
    posc = [0.12,0.25,0.37,0.05];
elseif filename == '1979_064_07_07_11_CHI_ARRAYS.txt';
    posc = [0.12,0.25,0.37,0.05];
elseif filename == '1979_064_10_16_00_CHI_ARRAYS.txt';
    posc = [0.12,0.25,0.37,0.05];
end


if npar > 2
    c = colorbar('Ticks',cb_tick);
    title(c,'\chi_R^2-\chi_{R_0}^2');
    c.Location = 'South';
    c.Position = posc;
    set(c, 'FontSize', 16);
    set(gca, 'Position', pos); % Resize contour plot
end

%if filename == '1979_062_10_23_58_CHI_ARRAYS.txt'; %GOOD
%    plotpos = [36 123 2302 1203];
%elseif filename == '1979_064_00_28_47_CHI_ARRAYS.txt'; %GOOD
%    posc = [0.12,0.25,0.37,0.05];
%elseif filename == '1979_064_07_07_11_CHI_ARRAYS.txt';
%    posc = [0.12,0.25,0.37,0.05];
%elseif filename == '1979_064_10_16_00_CHI_ARRAYS.txt';
%    posc = [0.12,0.25,0.37,0.05];
%end

plotpos = [36 123 2302 1203];
set(gcf, 'Position', plotpos);

%out1 = MATLAB PLOT ???
end
